Pooja Raichandani · Personal Portfolio
======================================

Files included
--------------
- index.html
- about.html
- experience.html
- projects.html
- skills.html
- contact.html
- styles.css
- script.js
- favicon.png
- profile.jpg (placeholder – replace with your own portrait)
- (Optional) Pooja Raichandani ATS CV.pdf  <-- Add your real CV with exactly this filename to enable the download button on About page.

How to use
----------
1) Replace `profile.jpg` with your photo (recommended size ~800x800px). Keep the same filename.
2) Add your real CV file named exactly: **Pooja Raichandani ATS CV.pdf** to the same folder if you want the About page "Download CV" button to work.
3) Open `index.html` in any browser to preview locally.
4) For best results, host these files on Netlify, GitHub Pages, or any static hosting.

Features
--------
- Light/Dark mode toggle (defaults to **Light**). Your choice persists via localStorage.
- Accent color switcher (Blue/Teal/Violet) with persistence.
- Responsive layout for desktop and mobile.
- Sticky navigation with active link highlighting.
- Clean card layouts, chips, and modern typography (Google Font: Inter).

Editing tips
------------
- To change the accent colors, update CSS variables in `styles.css` or use the header dots.
- To add more projects or experience, edit the respective HTML file sections wrapped in `.card` elements.
- The navigation, theme toggle, and accent switcher are included on every page for consistency.

Support
-------
If you want me to tweak copy, add animations, or expand sections (blog, testimonials, case studies), just ask!
