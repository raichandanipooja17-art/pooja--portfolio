
// =====================
// script.js - Theme, Accent, Active Link, Mobile Nav
// =====================

(function(){
  const root = document.documentElement;
  const body = document.body;

  // Light (default) / Dark toggle (persist in localStorage)
  const THEME_KEY = "pooja_theme";
  const ACCENT_KEY = "pooja_accent";

  function applyTheme(theme){
    // theme: "light" | "dark"
    if(theme === "dark"){
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
    localStorage.setItem(THEME_KEY, theme);
  }

  function currentTheme(){
    return localStorage.getItem(THEME_KEY) || "light";
  }

  // Apply saved theme immediately
  applyTheme(currentTheme());

  // Accent
  function applyAccent(accent){
    const valid = ["blue","teal","violet"];
    const val = valid.includes(accent) ? accent : "blue";
    body.setAttribute("data-accent", val);
    localStorage.setItem(ACCENT_KEY, val);
  }
  function currentAccent(){
    return localStorage.getItem(ACCENT_KEY) || "blue";
  }
  applyAccent(currentAccent());

  // Wire up controls when DOM is ready
  document.addEventListener("DOMContentLoaded", function(){
    // Theme toggle
    const themeBtn = document.getElementById("themeToggle");
    if(themeBtn){
      themeBtn.addEventListener("click", () => {
        applyTheme(currentTheme() === "light" ? "dark" : "light");
        themeBtn.setAttribute("aria-pressed", currentTheme() === "dark");
      });
      themeBtn.setAttribute("aria-pressed", currentTheme() === "dark");
    }

    // Accent dots
    const dots = document.querySelectorAll("[data-accent-dot]");
    dots.forEach(dot => {
      dot.addEventListener("click", () => {
        const val = dot.getAttribute("data-accent-dot");
        applyAccent(val);
      });
    });

    // Mobile menu
    const menuBtn = document.getElementById("menuBtn");
    const navLinks = document.getElementById("navLinks");
    if(menuBtn && navLinks){
      menuBtn.addEventListener("click", () => {
        navLinks.classList.toggle("open");
        menuBtn.setAttribute("aria-expanded", navLinks.classList.contains("open"));
      });
    }

    // Active link highlight
    const path = window.location.pathname.split("/").pop() || "index.html";
    if(navLinks){
      navLinks.querySelectorAll("a").forEach(a => {
        const href = a.getAttribute("href");
        if(href === path || (path === "" && href === "index.html")){
          a.classList.add("active");
        }
      });
    }
  });
})();
